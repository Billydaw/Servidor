<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\Routing\Annotation\Route;

class ContactaController extends AbstractController
{
    /**
     * @Route("/contacta", name="contacta")
     */
    public function index()
    {
        return $this->render('contacta/contact.html.twig', [
            'controller_name' => 'ContactaController',
        ]);
    }
}
